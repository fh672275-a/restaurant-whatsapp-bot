#!/bin/bash
# Restaurant WhatsApp Bot - Deployment Helper
# Helps deploy to free hosting (Render.com recommended)

echo "============================================"
echo "  Restaurant WhatsApp Bot - Deployment"
echo "============================================"
echo ""
echo "Available deployment options:"
echo ""
echo "  1. Render.com (RECOMMENDED - Easiest, Free)"
echo "     - Free web service + Free PostgreSQL"
echo "     - Auto-deploy from GitHub"
echo "     - URL: https://your-app.onrender.com"
echo ""
echo "  2. Railway.app ($5 free credit)"
echo "     - Persistent storage"
echo "     - URL: https://your-app.up.railway.app"
echo ""
echo "  3. Fly.io (Free with persistent volume)"
echo "     - SQLite works (no PostgreSQL needed)"
echo "     - URL: https://your-app.fly.dev"
echo ""
echo "  4. Show deployment instructions"
echo ""
echo "  5. Create GitHub-ready ZIP file"
echo ""
echo "  6. Exit"
echo ""
read -p "Select option (1-6): " choice

case $choice in
  1)
    echo ""
    echo "=== Render.com Deployment ==="
    echo ""
    echo "Step 1: Push code to GitHub"
    echo "  cd /home/z/my-project"
    echo "  git remote add origin https://github.com/YOUR_USERNAME/restaurant-whatsapp-bot.git"
    echo "  git push -u origin main"
    echo ""
    echo "Step 2: Go to https://render.com"
    echo "  - Sign up with GitHub"
    echo "  - New + → Web Service"
    echo "  - Connect your repository"
    echo "  - Settings:"
    echo "    Name: restaurant-whatsapp-bot"
    echo "    Environment: Node"
    echo "    Build Command: npm install"
    echo "    Start Command: node server.js"
    echo "    Instance Type: Free"
    echo "  - Environment Variables:"
    echo "    SESSION_SECRET = (any random string)"
    echo "    NODE_ENV = production"
    echo "  - Create Web Service"
    echo ""
    echo "Step 3: Add PostgreSQL Database"
    echo "  - New + → PostgreSQL (Free plan)"
    echo "  - Copy Internal Database URL"
    echo "  - Go to Web Service → Environment"
    echo "  - Add: DATABASE_URL = (paste URL)"
    echo "  - Manual Deploy → Clear cache & deploy"
    echo ""
    echo "Step 4: Get your URL!"
    echo "  https://restaurant-whatsapp-bot.onrender.com"
    echo ""
    echo "Step 5: Keep awake (optional)"
    echo "  - Go to https://uptimerobot.com (free)"
    echo "  - Add HTTP monitor: your URL + /login"
    echo "  - 5 min interval"
    ;;
  2)
    echo ""
    echo "=== Railway.app Deployment ==="
    echo ""
    echo "Step 1: Go to https://railway.app"
    echo "  - Sign up with GitHub"
    echo "  - New Project → Deploy from GitHub repo"
    echo "  - Select your repository"
    echo ""
    echo "Step 2: Add PostgreSQL"
    echo "  - New → Database → PostgreSQL"
    echo "  - DATABASE_URL auto-set ho jayega"
    echo ""
    echo "Step 3: Environment Variables"
    echo "  - SESSION_SECRET = random-string"
    echo "  - NODE_ENV = production"
    echo ""
    echo "Step 4: Deploy!"
    echo "  URL: https://restaurant-whatsapp-bot.up.railway.app"
    ;;
  3)
    echo ""
    echo "=== Fly.io Deployment ==="
    echo ""
    echo "Step 1: Install flyctl"
    echo "  curl -L https://fly.io/install.sh | sh"
    echo ""
    echo "Step 2: Sign up & login"
    echo "  flyctl auth signup"
    echo "  flyctl auth login"
    echo ""
    echo "Step 3: Deploy"
    echo "  cd /home/z/my-project"
    echo "  flyctl launch"
    echo "  - App name: restaurant-whatsapp-bot"
    echo "  - Region: nearest"
    echo "  - PostgreSQL: Yes"
    echo "  - Deploy: Yes"
    echo ""
    echo "URL: https://restaurant-whatsapp-bot.fly.dev"
    ;;
  4)
    echo ""
    echo "=== Deployment Instructions ==="
    echo ""
    echo "Read the full guide:"
    echo "  cat /home/z/my-project/DEPLOYMENT.md"
    echo ""
    echo "Or quick guide:"
    echo "  cat /home/z/my-project/README.md"
    ;;
  5)
    echo ""
    echo "=== Creating GitHub-ready ZIP ==="
    cd /home/z/my-project
    
    # Create deployment ZIP
    rm -f /home/z/my-project/download/restaurant-bot-deploy.zip 2>/dev/null
    mkdir -p /home/z/my-project/download
    
    # Create ZIP excluding heavy files
    zip -r /home/z/my-project/download/restaurant-bot-deploy.zip \
      . -x "node_modules/*" "data/*" "logs/*" "skills/*" "upload/*" \
         ".git/*" "*.db" "*.db-wal" "*.db-shm" "*.log" 2>&1 | tail -5
    
    echo ""
    echo "✅ ZIP created:"
    ls -lh /home/z/my-project/download/restaurant-bot-deploy.zip
    echo ""
    echo "Download this ZIP and:"
    echo "  1. Extract it"
    echo "  2. Push to GitHub"
    echo "  3. Deploy on Render.com/Railway.app/Fly.io"
    ;;
  6)
    echo "Goodbye!"
    exit 0
    ;;
  *)
    echo "Invalid option"
    ;;
esac
